﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classlib
{
   public class clsTurtles
    {
       public string type { get; set; }
       public string flag { get; set; }
       public string locations { get; set; }
       public string size { get; set; }
       public string lifespan { get; set; }
       public string diet { get; set; }
       public string description { get; set; }

       public static List<clsTurtles> GetAllTurtles()
       {
           List<clsTurtles> x = new List<clsTurtles>();
           clsTurtles x1 = new clsTurtles { type = "Green Turtle", flag = "../turtles/img1.jpg", locations = "Tropical and subtropical oceans worldwide", size = "Up to 1.5m and up to 300kg", lifespan = "Over 80 years",
                                            diet = "Herbivore",
                                            description = "The green turtle is a large, weighty sea turtle with a wide, smooth carapace, or shell. It inhabits tropical and subtropical coastal waters around the world and has been observed clambering onto land to sunbathe. It is named not for the color of its shell, which is normally brown or olive depending on its habitat, but for the greenish color of its skin. There are two types of green turtles—scientists are currently debating whether they are subspecies or separate species—including the Atlantic green turtle, normally found off the shores of Europe and North America, and the Eastern Pacific green turtle, which has been found in coastal waters from Alaska to Chile."
           };
           x.Add(x1);
           clsTurtles x2 = new clsTurtles
           {
               type = "Loggerhead Turtle",
               flag = "../turtles/img2.jpg",
               locations = "Tropical and subtropical oceans worldwide",
               size = "90cm, 115kg",
               lifespan = "More than 50 years",
               diet = "Carnivore",
               description = "Loggerhead turtles are the most abundant of all the marine turtle species in U.S. waters. But persistent population declines due to pollution, shrimp trawling, and development in their nesting areas, among other factors, have kept this wide-ranging seagoer on the threatened species list since 1978. Their enormous range encompasses all but the most frigid waters of the world's oceans. They seem to prefer coastal habitats, but often frequent inland water bodies and will travel hundreds of miles out to sea."
           };
           x.Add(x2);
           clsTurtles x3 = new clsTurtles
           {
               type = "Leatherback Turtle",
               flag = "../turtles/img3.jpg",
               locations = "All tropical and subtropical oceans",
               size = "Up to 2m, up to 900kg",
               lifespan = "45 years",
               diet = "Carnivore",
               description = "Leatherbacks are the largest turtles on Earth, growing up to seven feet (two meters) long and exceeding 2,000 pounds (900 kilograms). These reptilian relics are the only remaining representatives of a family of turtles that traces its evolutionary roots back more than 100 million years. Once prevalent in every ocean except the Arctic and Antarctic, the leatherback population is rapidly declining in many parts of the world. While all other sea turtles have hard, bony shells, the inky-blue carapace of the leatherback is somewhat flexible and almost rubbery to the touch. Ridges along the carapace help give it a more hydrodynamic structure. Leatherbacks can dive to depths of 4,200 feet (1,280 meters)—deeper than any other turtle—and can stay down for up to 85 minutes."
           };
           x.Add(x3);
           clsTurtles x4 = new clsTurtles
           {
               type = "Hawksbill Sea Turtle",
               flag = "../turtles/img4.jpg",
               locations = "Along the Atlantic Coast of USA",
               size = "around 60cm, up to 100kg",
               lifespan = "20-70 years",
               diet = "Carnivore",
               description = "The prehistoric-looking alligator snapping turtle is the largest freshwater turtle in North America and among the largest in the world. With its spiked shell, beaklike jaws, and thick, scaled tail, this species is often referred to as the 'dinosaur of the turtle world.' Found almost exclusively in the rivers, canals, and lakes of the southeastern United States, alligator snappers can live to be 50 to 100 years old. Males average 26 inches (66 centimeters) in shell length and weigh about 175 pounds (80 kilograms), although they have been known to exceed 220 pounds (100 kilograms). The much smaller females top out at around 50 pounds (23 kilograms)."
           };
           x.Add(x4);

           clsTurtles x5 = new clsTurtles
           {
               type = "Alligator Snapping Turtle",
               flag = "../turtles/img5.jpg",
               locations = "Along the Atlantic Coast of USA",
               size = "around 60cm, up to 100kg",
               lifespan = "20-70 years",
               diet = "Carnivore",
               description = "The prehistoric-looking alligator snapping turtle is the largest freshwater turtle in North America and among the largest in the world. With its spiked shell, beaklike jaws, and thick, scaled tail, this species is often referred to as the 'dinosaur of the turtle world.' Found almost exclusively in the rivers, canals, and lakes of the southeastern United States, alligator snappers can live to be 50 to 100 years old. Males average 26 inches (66 centimeters) in shell length and weigh about 175 pounds (80 kilograms), although they have been known to exceed 220 pounds (100 kilograms). The much smaller females top out at around 50 pounds (23 kilograms)."
           };
           x.Add(x5);


           clsTurtles x6 = new clsTurtles
           {
               type = "Kemp's Ridley Sea Turtle",
               flag = "../turtles/img6.JPG",
               locations = "Coastal areas of the North Atlantic",
               size = "65cm, up to 45kg",
               lifespan = "Around 50 years",
               diet = "Omnivore",
               description = "The Kemp’s ridley turtle is the world’s most endangered sea turtle, and with a worldwide female nesting population roughly estimated at just 1,000 individuals, its survival truly hangs in the balance. Their perilous situation is attributed primarily to the over-harvesting of their eggs during the last century. And though their nesting grounds are protected and many commercial fishing fleets now use turtle excluder devices in their nets, these turtles have not been able to rebound. For this reason, their nesting processions, called arribadas, make for especially high drama. During an arribada, females take over entire portions of beaches, lugging their big bodies through the sand with their flippers until they find a satisfying spot to lay their eggs. Even more riveting is the later struggle to the ocean of each tiny, vulnerable hatchling. Beset by predators, hatchlings make this journey at night, breaking out of their shells using their caruncle, a single temporary tooth grown just for this purpose."
           };
           x.Add(x6);
           clsTurtles x7 = new clsTurtles
           {
               type = "Olive Ridley Turtle",
               flag = "../turtles/img7.jpg",
               locations = "Tropical coastal areas around the world",
               size = "70cm, 45kg",
               lifespan = "50 years",
               diet = "Omnivore",
               description = "The olive ridley turtle is named for the generally greenish color of its skin and shell, or carapace. It is closely related to the Kemp’s ridley, with the primary distinction being that olive ridleys are found only in warmer waters, including the southern Atlantic, Pacific and Indian Oceans. Olive and Kemp’s ridleys are the smallest of the sea turtles, weighing up to 100 pounds (45 kilograms) and reaching only about 2 feet (65 centimeters) in shell length. The olive ridley has a slightly smaller head and smaller shell than the Kemp’s."
           };
           x.Add(x7);
           clsTurtles x8 = new clsTurtles
           {
               type = "Eastern Snake Necked Turtle",
               flag = "../turtles/img8.jpg",
               locations = "Eastern Australia",
               size = "Up to 30cm",
               lifespan = "25 years",
               diet = "Carnivore",
               description = "Snake-necked turtles, as the name suggests, have an unusually long neck. Their necks may be up to 60 percent of their carapace length. Their carapace is oval and flattened, usually dark-brown to black measuring up to 11 inches (27.5 cm) in length. Scutes are shed as the animals grow. The males have a longer, thicker tail than females and a concave plastron. They are excellent swimmers; they have large, webbed feet with sharp claws used to tear apart food."
           };
           x.Add(x8);
           return x;
       }
    }
}
