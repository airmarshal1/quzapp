﻿/// <reference path="../Scripts/angular.js" />
/// <reference path="../Scripts/angular-route.js" />
/// <reference path="../bootstrap/jquery_ui/external/jquery/jquery.js" />
var app = angular.module('myappp', ['ngRoute', 'ngCookies'])
            .config(function ($routeProvider, $locationProvider) {
                $routeProvider.caseInsensitiveMatch = true;
                $routeProvider.when("/home", {
                    templateUrl: "Templates/home.html",
                    controller: "homeController"
                }).when("/turtless", {
                    templateUrl: "Templates/turtles.html",
                    controller: "turtlesController as turtlesCtrl"
                }).when("/turtlessQuiz", {
                    templateUrl: "Templates/turtlessQuiz.html",
                    controller: "turtlessQuizController as turtlessQuizCtrl"
                }).otherwise({
                    redirectTo: "/home"
                })
                $locationProvider.html5Mode(true);
            })
            .factory("getAllTurtles", function ($http) {
                var obj = {};
                obj.fetchUserDetails = function () {
                    return $http.get("../Services/svTurtles.asmx/GetAllTurtlesQuiz");
                }
                obj.Quizmetrics = function () {
                    return $http.get('../Services/svQuestions.asmx/GetAllQuestions');
                }
                obj.fetchLoginDetails = function () {
                    return $http.get("../Services/svLogin.asmx/GetAllLogin");
                }
                return obj;
            })
            .controller("homeController", function ($scope) {
                $scope.mainmessageheader = "This is the main page that displays when i load the page.";
            })
            .controller("turtlesController", function ($http) {
                var vm = this;
                vm.message = "Turtle Facts Quiz!!!!!";
                vm.message2 = "Learn about all the turtles below before you decide to take on the TURTLE QUIZ";
                vm.searchk = "";
                $http.get("../Services/svTurtles.asmx/GetAllTurtles").then(function (response) { vm.value = response.data; });
                vm.activeTurtle = {};
                vm.changeActiveTurtle = function (index) {
                    vm.activeTurtle = index;
                }
                vm.hideController = false;
                vm.activeQuiz = function () {
                    vm.hideController = true;
                }
            })
            .controller("turtlessQuizController", function (getAllTurtles) {
                var vm = this;
                loadData();
                function loadData() {
                    getAllTurtles.fetchUserDetails().then(function (response) {
                        vm.h2 = "Progress: ";
                        vm.h4 = "Legend: ";
                        vm.p1 = "Answered ";
                        vm.p2 = "Unanswered ";
                        vm.h3 = "Questions: ";
                        vm.activeQuestion = Math.floor(Math.random() * response.data.length);
                        var numberOfQuestionsAnswered = 0;
                        vm.value = response.data;
                        vm.error = false;
                        vm.finalize = false;
                        vm.resultActive = false;
                        var score = 0;

                        vm.SetActiveQuestion = function (index) {
                            if (index == undefined) {
                                var breakOut = false;
                                var quizlengthNew = response.data.length - 1;
                                while (!breakOut) {
                                    vm.activeQuestion = vm.activeQuestion < quizlengthNew ? ++vm.activeQuestion : 0
                                    if (vm.activeQuestion == 0) {
                                        vm.error = true;
                                    }
                                    if (response.data[vm.activeQuestion].selected == null) {
                                        breakOut = true;
                                    }
                                }
                            }
                            else { vm.activeQuestion = index; }
                        }
                        vm.questionAnswered = function () {
                            var quizlength = response.data.length;
                            if (response.data[vm.activeQuestion].selected != null) {
                                numberOfQuestionsAnswered++;
                                if (numberOfQuestionsAnswered >= quizlength) {
                                    //finalize our quiz
                                    for (var i = 0; i < quizlength; i++) {
                                        if (response.data[i].selected == null) {
                                            SetActiveQuestion(i);
                                            return;
                                        }
                                    }

                                    vm.error = false;
                                    vm.finalize = true;
                                    return;
                                }
                            }
                            vm.SetActiveQuestion();
                        }
                        vm.selectedAnswer = function (index) {
                            //response.data[vm.activeQuestion].selected = 1;
                            response.data[vm.activeQuestion].selected = index;

                            // vm.questionAnswered();
                        }
                        vm.getAnswerClass = function (index) {
                            if (index === response.data[vm.activeQuestion].selected) {
                                return "bg-success";
                            }
                            else {
                                return g(); function g() {
                                    $(this).css({
                                        "background-color": "white"
                                    });
                                }
                            }
                        }
                        vm.finalizeAnswers = function () {
                            vm.finalize = false;
                            vm.resultActive = true;
                            numberOfQuestionsAnswered = 0;
                            vm.activeQuestion = 0;
                            markQuiz();
                            function markQuiz() {
                                //if (response.data[vm.activeQuestion].selected == response.data[vm.activeQuestion].correct) {
                                //   vm.score++;
                                //    return;
                                //}
                            }
                        }
                    });
                }
            })